import Phaser from 'phaser';

export default class GameScene extends Phaser.Scene {
    init(){
        
    }
    preload(){
        //游戏资源预加载
    }
    create(){
        this.add.sprite(0, 0, 'GameScene_background').setOrigin(0, 0);
        this.add.sprite(0, 0, 'GameScene_backgroundBorder').setOrigin(0, 0);
        this.add.sprite(960, 495, 'GameScene_center');
        this.add.sprite(852, 495, 'GameScene_rizhiBar');
        this.add.sprite(960, 390, 'GameScene_rizhiBarLand');
        this.add.sprite(1073, 495, 'GameScene_rizhiBar');
        this.add.sprite(960, 606, 'GameScene_rizhiBarLand');
        this.addDoraGroup(58,33);
        this.addFengGroup();
        this.addMyHandGroup(215,906,87);
        this.addLeftHandGroup(392,172,35);
        this.addRightHandGroup(1469,255,35);
        this.addUpHandGroup(673,17,50);
        
        this.addUpRiverGroup(798,105,55);
        this.addBottomRiverGroup(798,615,55);
        this.addLeftRiverGroup(468,348,45);
        this.addRightRiverGroup(1130,348,45);
        
        this.usernameText = this.add.text(960, 495, '00', {
            fontFamily: 'notoSerif',
            fill: "#FFFFFF",
            fontSize: 72,
            stroke: '#333',
            strokeThickness: 2
        }).setOrigin(0.5, 0.5);
    }
    update(){
    }
    render(){
        //游戏自定义渲染
    }
    addDoraGroup(x,y){
        this.add.sprite(x,y+22,'Common_bottomB').setOrigin(0, 0);
        this.add.sprite(x+54,y+22,'Common_bottomB').setOrigin(0, 0);
        this.add.sprite(x+54*2,y+22,'Common_bottomB').setOrigin(0, 0);
        this.add.sprite(x+54*3,y+22,'Common_bottomB').setOrigin(0, 0);
        this.add.sprite(x+54*4,y+22,'Common_bottomB').setOrigin(0, 0);
        
        this.add.sprite(x,y,'Common_bottomM1').setOrigin(0, 0);
        this.add.sprite(x+54,y,'Common_bottomB').setOrigin(0, 0);
        this.add.sprite(x+54*2,y,'Common_bottomB').setOrigin(0, 0);
        this.add.sprite(x+54*3,y,'Common_bottomB').setOrigin(0, 0);
        this.add.sprite(x+54*4,y,'Common_bottomB').setOrigin(0, 0);
    }
    addFengGroup(){
        this.topFeng = this.add.text(960, 430, '东', {
            fontFamily: 'cangershuyuanti',
            fill: "#28b8a2",
            fontSize: 30
        }).setOrigin(0.5, 0.5);
        
        this.leftFeng = this.add.text(895, 495, '南', {
            fontFamily: 'cangershuyuanti',
            fill: "#28b8a2",
            fontSize: 30
        }).setOrigin(0.5, 0.5).setRotation(Math.PI*1.5);
        
        this.bottomFeng = this.add.text(960, 560, '西', {
            fontFamily: 'cangershuyuanti',
            fill: "#28b8a2",
            fontSize: 30
        }).setOrigin(0.5, 0.5).setRotation(Math.PI);
        
        this.rightFeng = this.add.text(1025, 495, '北', {
            fontFamily: 'cangershuyuanti',
            fill: "#28b8a2",
            fontSize: 30
        }).setOrigin(0.5, 0.5).setRotation(Math.PI/2);
    }
    addMyHandGroup(x,y,w){
        var tx = x;
        for(var i=0;i<13;i++){
            tx = x + i * w;
            this.add.sprite(tx,y,'Common_myM1').setOrigin(0, 0).setScale(w/75,w/75);
        }
        tx = x + 13.5 * w;
        this.add.sprite(tx,y,'Common_myM1').setOrigin(0, 0).setScale(w/75,w/75);
    }
    addUpHandGroup(x,y,w){
        var tx = x - 1.5 * w;
        this.add.sprite(tx,y,'Common_upB').setOrigin(0, 0).setScale(w/40,w/40);
        tx = x;
        for(var i=0;i<13;i++){
            tx = x + i * w;
            this.add.sprite(tx,y,'Common_upB').setOrigin(0, 0).setScale(w/40,w/40);
        }
    }
    addLeftHandGroup(x,y,h){
        var ty = y;
        for(var i=0;i<13;i++){
            ty = y + i * h;
            this.add.sprite(x,ty,'Common_leftB').setOrigin(0, 0).setScale(h/28,h/28);
        }
        ty = y + 13.5 * h;
        this.add.sprite(x,ty,'Common_leftB').setOrigin(0, 0).setScale(h/28,h/28);
    }
    addRightHandGroup(x,y,h){
        var ty = y - 1.5 * h;
        this.add.sprite(x,ty,'Common_rightB').setOrigin(0, 0).setScale(h/28,h/28);
        ty = y;
        for(var i=0;i<13;i++){
            ty = y + i * h;
            this.add.sprite(x,ty,'Common_rightB').setOrigin(0, 0).setScale(h/28,h/28);
        }
    }
    addUpRiverGroup(x,y,w){
        var tx = x;
        var ty = y;
        var h = w/55*63;
        for(var i=0;i<6;i++){
            for(var j=0;j<4;j++){
                tx = x + i * w;
                ty = y + j * h;
                this.add.sprite(tx,ty,'Common_bottomM1').setOrigin(0, 0).setScale(w/55,w/55);
            }
        }
    }
    addBottomRiverGroup(x,y,w){
        var tx = x;
        var ty = y;
        var h = w/55*63;
        for(var i=0;i<6;i++){
            for(var j=0;j<4;j++){
                tx = x + i * w;
                ty = y + j * h;
                this.add.sprite(tx,ty,'Common_bottomM1').setOrigin(0, 0).setScale(w/55,w/55);
            }
        }
    }
    addLeftRiverGroup(x,y,h){
        var tx = x;
        var ty = y;
        var w = h/27*49;
        for(var i=0;i<4;i++){
            for(var j=0;j<6;j++){
                tx = x + i * w;
                ty = y + j * h;
                this.add.sprite(tx,ty,'Common_leftM1').setOrigin(0, 0).setScale(h/27,h/27);
            }
        }
    }
    addRightRiverGroup(x,y,h){
        var tx = x;
        var ty = y;
        var w = h/27*49;
        for(var i=0;i<4;i++){
            for(var j=0;j<6;j++){
                tx = x + i * w;
                ty = y + j * h;
                this.add.sprite(tx,ty,'Common_rightM1').setOrigin(0, 0).setScale(h/27,h/27);
            }
        }
    }
};