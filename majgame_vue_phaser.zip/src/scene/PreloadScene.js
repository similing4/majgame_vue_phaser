import Phaser from 'phaser';

export default class PreloadScene extends Phaser.Scene {
	init(){
        this.preloadBar = null;
    }
    preload(){
        this.add.sprite(0, 0, 'preloadScene_background').setOrigin(0, 0);
        this.add.sprite(239, 778, 'preloadScene_loadingBarBase').setOrigin(0, 0);
        this.preloadBar = this.add.sprite(248, 787, 'preloadScene_loadingBar').setOrigin(0, 0);
        this.add.sprite(233, 778, 'preloadScene_loadingFront').setOrigin(0, 0);
        this.load.on('progress', (value) => {
            this.preloadBar.setScale(value,1);
        });
        this.load.image('GamePreloadScene_background', require("../assets/images/game/loading.jpg"));
        this.load.image('MenuScene_background', require("../assets/images/main/background/menu_background.jpg"));
        this.load.image('MenuScene_charactorChangeCardBar', require("../assets/images/main/btn/charactor_change_card_bar.png"));
        this.load.image('MenuScene_activityBtn', require("../assets/images/main/btn/menu_activity_btn.png"));
        this.load.image('MenuScene_bottomBar', require("../assets/images/main/btn/menu_bottom_bar.png"));
        this.load.image('MenuScene_settingBtn', require("../assets/images/main/btn/menu_setting_btn.png"));
        this.load.image('MenuScene_shopBtn', require("../assets/images/main/btn/menu_shop_btn.png"));
        this.load.image('MenuScene_topBar', require("../assets/images/main/btn/menu_top_bar.png"));
        this.load.image('MenuScene_zhanjiBtn', require("../assets/images/main/btn/menu_zhanji_btn.png"));
        this.load.image('MenuScene_Message', require("../assets/images/main/btn/message.png"));
        this.load.image('MenuScene_moneyBar', require("../assets/images/main/btn/money_bar.png"));
        this.load.image('MenuScene_roomCreateBtn', require("../assets/images/main/btn/room_create_btn.png"));
        this.load.image('MenuScene_roomInBtn', require("../assets/images/main/btn/room_in_btn.png"));
        this.load.image('MenuScene_userIcon', require("../assets/images/main/user/user_icon.png"));
        this.load.image('MenuScene_userBar', require("../assets/images/main/btn/user_bar.png"));
        //游戏资源预加载
    }
    create(){
        this.preloadBar.cropEnabled = false;
        var font = require('../assets/font/cangershuyuanti.ttf');
        var font2 = require('../assets/font/notoSerif_bold.ttf');
        var fontFace = new FontFace("cangershuyuanti","local('cangershuyuanti'),url("+font+") format('ttf'),url("+font+")");
        var fontFace2 = new FontFace("cangershuyuanti","local('cangershuyuanti'),url("+font2+") format('ttf'),url("+font2+")");
        var that = this;
        fontFace.load().then(function(loadedFontFace) {
            document.fonts.add(loadedFontFace);
            return fontFace2.load();
        }).then(function(loadedFontFace) {
            document.fonts.add(loadedFontFace);
            that.scene.start('MenuScene');
        });
    }
};