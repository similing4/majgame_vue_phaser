import Phaser from 'phaser';

export default class GamePreloadScene extends Phaser.Scene {
	init(){
        this.preloadBar = null;
    }
    preload(){
        this.add.sprite(0, 0, 'GamePreloadScene_background').setOrigin(0, 0);
        this.add.sprite(239, 778, 'preloadScene_loadingBarBase').setOrigin(0, 0);
        this.preloadBar = this.add.sprite(248, 787, 'preloadScene_loadingBar').setOrigin(0, 0);
        this.add.sprite(233, 778, 'preloadScene_loadingFront').setOrigin(0, 0);
        var that = this;
        this.load.on('progress', function(value) {
            that.preloadBar.setScale(value,1);
        });
        
        this.load.image('GameScene_background', require("../assets/images/game/background.jpg"));
        this.load.image('GameScene_backgroundBorder', require("../assets/images/game/background_border.png"));
        this.load.image('GameScene_center', require("../assets/images/game/center.png"));
        this.load.image('GameScene_centerHighLight', require("../assets/images/game/center_highlight.png"));
        this.load.image('GameScene_rizhiBar', require("../assets/images/game/rizhi_bar.png"));
        this.load.image('GameScene_rizhiBarLand', require("../assets/images/game/rizhi_bar_land.png"));
        this.load.image('GameScene_userBorder', require("../assets/images/game/user_border.png"));
        this.load.image('GameScene_chi',require("../assets/images/game/opera/chi.png"))
        this.load.image('GameScene_kang',require("../assets/images/game/opera/kang.png"))
        this.load.image('GameScene_peng',require("../assets/images/game/opera/peng.png"))
        this.load.image('GameScene_rizhi',require("../assets/images/game/opera/rizhi.png"))
        this.load.image('GameScene_rong',require("../assets/images/game/opera/rong.png"))
        this.load.image('GameScene_zimo',require("../assets/images/game/opera/zimo.png"))
        this.load.image('GameScene_settingBack',require("../assets/images/game/opera/setting_back.png"))
        this.load.image('GameScene_settingBackground',require("../assets/images/game/opera/setting_background.png"))
        this.load.image('GameScene_settingFace',require("../assets/images/game/opera/setting_face.png"))
        this.load.image('GameScene_settingYY',require("../assets/images/game/opera/setting_mai.png"))
        this.load.image('GameScene_settingSetting',require("../assets/images/game/opera/setting_setting.png"))
        
        
        this.load.image('Common_bottomB',require("../assets/images/maj/bottom/e_mj_b_up.png"))
        this.load.image('Common_leftB',require("../assets/images/maj/left/e_mj_left.png"))
        this.load.image('Common_rightB',require("../assets/images/maj/right/e_mj_right.png"))
        this.load.image('Common_upB',require("../assets/images/maj/my/e_mj_up.png"))
        this.load.image('Common_bottomM1',require("../assets/images/maj/bottom/m1.png"))
        this.load.image('Common_bottomM2',require("../assets/images/maj/bottom/m2.png"))
        this.load.image('Common_bottomM3',require("../assets/images/maj/bottom/m3.png"))
        this.load.image('Common_bottomM4',require("../assets/images/maj/bottom/m4.png"))
        this.load.image('Common_bottomM5',require("../assets/images/maj/bottom/m5.png"))
        this.load.image('Common_bottomM6',require("../assets/images/maj/bottom/m6.png"))
        this.load.image('Common_bottomM7',require("../assets/images/maj/bottom/m7.png"))
        this.load.image('Common_bottomM8',require("../assets/images/maj/bottom/m8.png"))
        this.load.image('Common_bottomM9',require("../assets/images/maj/bottom/m9.png"))
        
        this.load.image('Common_bottomP1',require("../assets/images/maj/bottom/p1.png"))
        this.load.image('Common_bottomP2',require("../assets/images/maj/bottom/p2.png"))
        this.load.image('Common_bottomP3',require("../assets/images/maj/bottom/p3.png"))
        this.load.image('Common_bottomP4',require("../assets/images/maj/bottom/p4.png"))
        this.load.image('Common_bottomP5',require("../assets/images/maj/bottom/p5.png"))
        this.load.image('Common_bottomP6',require("../assets/images/maj/bottom/p6.png"))
        this.load.image('Common_bottomP7',require("../assets/images/maj/bottom/p7.png"))
        this.load.image('Common_bottomP8',require("../assets/images/maj/bottom/p8.png"))
        this.load.image('Common_bottomP9',require("../assets/images/maj/bottom/p9.png"))
        
        this.load.image('Common_bottomS1',require("../assets/images/maj/bottom/s1.png"))
        this.load.image('Common_bottomS2',require("../assets/images/maj/bottom/s2.png"))
        this.load.image('Common_bottomS3',require("../assets/images/maj/bottom/s3.png"))
        this.load.image('Common_bottomS4',require("../assets/images/maj/bottom/s4.png"))
        this.load.image('Common_bottomS5',require("../assets/images/maj/bottom/s5.png"))
        this.load.image('Common_bottomS6',require("../assets/images/maj/bottom/s6.png"))
        this.load.image('Common_bottomS7',require("../assets/images/maj/bottom/s7.png"))
        this.load.image('Common_bottomS8',require("../assets/images/maj/bottom/s8.png"))
        this.load.image('Common_bottomS9',require("../assets/images/maj/bottom/s9.png"))
        
        this.load.image('Common_bottomTON',require("../assets/images/maj/bottom/ton.png"))
        this.load.image('Common_bottomNAN',require("../assets/images/maj/bottom/nan.png"))
        this.load.image('Common_bottomSHA',require("../assets/images/maj/bottom/sha.png"))
        this.load.image('Common_bottomPEI',require("../assets/images/maj/bottom/pei.png"))
        this.load.image('Common_bottomCHU',require("../assets/images/maj/bottom/chu.png"))
        this.load.image('Common_bottomHAT',require("../assets/images/maj/bottom/hat.png"))
        this.load.image('Common_bottomHAK',require("../assets/images/maj/bottom/hak.png"))

        this.load.image('Common_leftM1',require("../assets/images/maj/left/m1.png"))
        this.load.image('Common_leftM2',require("../assets/images/maj/left/m2.png"))
        this.load.image('Common_leftM3',require("../assets/images/maj/left/m3.png"))
        this.load.image('Common_leftM4',require("../assets/images/maj/left/m4.png"))
        this.load.image('Common_leftM5',require("../assets/images/maj/left/m5.png"))
        this.load.image('Common_leftM6',require("../assets/images/maj/left/m6.png"))
        this.load.image('Common_leftM7',require("../assets/images/maj/left/m7.png"))
        this.load.image('Common_leftM8',require("../assets/images/maj/left/m8.png"))
        this.load.image('Common_leftM9',require("../assets/images/maj/left/m9.png"))
        
        this.load.image('Common_leftP1',require("../assets/images/maj/left/p1.png"))
        this.load.image('Common_leftP2',require("../assets/images/maj/left/p2.png"))
        this.load.image('Common_leftP3',require("../assets/images/maj/left/p3.png"))
        this.load.image('Common_leftP4',require("../assets/images/maj/left/p4.png"))
        this.load.image('Common_leftP5',require("../assets/images/maj/left/p5.png"))
        this.load.image('Common_leftP6',require("../assets/images/maj/left/p6.png"))
        this.load.image('Common_leftP7',require("../assets/images/maj/left/p7.png"))
        this.load.image('Common_leftP8',require("../assets/images/maj/left/p8.png"))
        this.load.image('Common_leftP9',require("../assets/images/maj/left/p9.png"))
        
        this.load.image('Common_leftS1',require("../assets/images/maj/left/s1.png"))
        this.load.image('Common_leftS2',require("../assets/images/maj/left/s2.png"))
        this.load.image('Common_leftS3',require("../assets/images/maj/left/s3.png"))
        this.load.image('Common_leftS4',require("../assets/images/maj/left/s4.png"))
        this.load.image('Common_leftS5',require("../assets/images/maj/left/s5.png"))
        this.load.image('Common_leftS6',require("../assets/images/maj/left/s6.png"))
        this.load.image('Common_leftS7',require("../assets/images/maj/left/s7.png"))
        this.load.image('Common_leftS8',require("../assets/images/maj/left/s8.png"))
        this.load.image('Common_leftS9',require("../assets/images/maj/left/s9.png"))
        
        this.load.image('Common_leftTON',require("../assets/images/maj/left/ton.png"))
        this.load.image('Common_leftNAN',require("../assets/images/maj/left/nan.png"))
        this.load.image('Common_leftSHA',require("../assets/images/maj/left/sha.png"))
        this.load.image('Common_leftPEI',require("../assets/images/maj/left/pei.png"))
        this.load.image('Common_leftCHU',require("../assets/images/maj/left/chu.png"))
        this.load.image('Common_leftHAT',require("../assets/images/maj/left/hat.png"))
        this.load.image('Common_leftHAK',require("../assets/images/maj/left/hak.png"))

        this.load.image('Common_rightM1',require("../assets/images/maj/right/m1.png"))
        this.load.image('Common_rightM2',require("../assets/images/maj/right/m2.png"))
        this.load.image('Common_rightM3',require("../assets/images/maj/right/m3.png"))
        this.load.image('Common_rightM4',require("../assets/images/maj/right/m4.png"))
        this.load.image('Common_rightM5',require("../assets/images/maj/right/m5.png"))
        this.load.image('Common_rightM6',require("../assets/images/maj/right/m6.png"))
        this.load.image('Common_rightM7',require("../assets/images/maj/right/m7.png"))
        this.load.image('Common_rightM8',require("../assets/images/maj/right/m8.png"))
        this.load.image('Common_rightM9',require("../assets/images/maj/right/m9.png"))
        
        this.load.image('Common_rightP1',require("../assets/images/maj/right/p1.png"))
        this.load.image('Common_rightP2',require("../assets/images/maj/right/p2.png"))
        this.load.image('Common_rightP3',require("../assets/images/maj/right/p3.png"))
        this.load.image('Common_rightP4',require("../assets/images/maj/right/p4.png"))
        this.load.image('Common_rightP5',require("../assets/images/maj/right/p5.png"))
        this.load.image('Common_rightP6',require("../assets/images/maj/right/p6.png"))
        this.load.image('Common_rightP7',require("../assets/images/maj/right/p7.png"))
        this.load.image('Common_rightP8',require("../assets/images/maj/right/p8.png"))
        this.load.image('Common_rightP9',require("../assets/images/maj/right/p9.png"))
        
        this.load.image('Common_rightS1',require("../assets/images/maj/right/s1.png"))
        this.load.image('Common_rightS2',require("../assets/images/maj/right/s2.png"))
        this.load.image('Common_rightS3',require("../assets/images/maj/right/s3.png"))
        this.load.image('Common_rightS4',require("../assets/images/maj/right/s4.png"))
        this.load.image('Common_rightS5',require("../assets/images/maj/right/s5.png"))
        this.load.image('Common_rightS6',require("../assets/images/maj/right/s6.png"))
        this.load.image('Common_rightS7',require("../assets/images/maj/right/s7.png"))
        this.load.image('Common_rightS8',require("../assets/images/maj/right/s8.png"))
        this.load.image('Common_rightS9',require("../assets/images/maj/right/s9.png"))
        
        this.load.image('Common_rightTON',require("../assets/images/maj/right/ton.png"))
        this.load.image('Common_rightNAN',require("../assets/images/maj/right/nan.png"))
        this.load.image('Common_rightSHA',require("../assets/images/maj/right/sha.png"))
        this.load.image('Common_rightPEI',require("../assets/images/maj/right/pei.png"))
        this.load.image('Common_rightCHU',require("../assets/images/maj/right/chu.png"))
        this.load.image('Common_rightHAT',require("../assets/images/maj/right/hat.png"))
        this.load.image('Common_rightHAK',require("../assets/images/maj/right/hak.png"))

        this.load.image('Common_myM1',require("../assets/images/maj/my/m1.png"))
        this.load.image('Common_myM2',require("../assets/images/maj/my/m2.png"))
        this.load.image('Common_myM3',require("../assets/images/maj/my/m3.png"))
        this.load.image('Common_myM4',require("../assets/images/maj/my/m4.png"))
        this.load.image('Common_myM5',require("../assets/images/maj/my/m5.png"))
        this.load.image('Common_myM6',require("../assets/images/maj/my/m6.png"))
        this.load.image('Common_myM7',require("../assets/images/maj/my/m7.png"))
        this.load.image('Common_myM8',require("../assets/images/maj/my/m8.png"))
        this.load.image('Common_myM9',require("../assets/images/maj/my/m9.png"))
        
        this.load.image('Common_myP1',require("../assets/images/maj/my/p1.png"))
        this.load.image('Common_myP2',require("../assets/images/maj/my/p2.png"))
        this.load.image('Common_myP3',require("../assets/images/maj/my/p3.png"))
        this.load.image('Common_myP4',require("../assets/images/maj/my/p4.png"))
        this.load.image('Common_myP5',require("../assets/images/maj/my/p5.png"))
        this.load.image('Common_myP6',require("../assets/images/maj/my/p6.png"))
        this.load.image('Common_myP7',require("../assets/images/maj/my/p7.png"))
        this.load.image('Common_myP8',require("../assets/images/maj/my/p8.png"))
        this.load.image('Common_myP9',require("../assets/images/maj/my/p9.png"))
        
        this.load.image('Common_myS1',require("../assets/images/maj/my/s1.png"))
        this.load.image('Common_myS2',require("../assets/images/maj/my/s2.png"))
        this.load.image('Common_myS3',require("../assets/images/maj/my/s3.png"))
        this.load.image('Common_myS4',require("../assets/images/maj/my/s4.png"))
        this.load.image('Common_myS5',require("../assets/images/maj/my/s5.png"))
        this.load.image('Common_myS6',require("../assets/images/maj/my/s6.png"))
        this.load.image('Common_myS7',require("../assets/images/maj/my/s7.png"))
        this.load.image('Common_myS8',require("../assets/images/maj/my/s8.png"))
        this.load.image('Common_myS9',require("../assets/images/maj/my/s9.png"))
        
        this.load.image('Common_myTON',require("../assets/images/maj/my/ton.png"))
        this.load.image('Common_myNAN',require("../assets/images/maj/my/nan.png"))
        this.load.image('Common_mySHA',require("../assets/images/maj/my/sha.png"))
        this.load.image('Common_myPEI',require("../assets/images/maj/my/pei.png"))
        this.load.image('Common_myCHU',require("../assets/images/maj/my/chu.png"))
        this.load.image('Common_myHAT',require("../assets/images/maj/my/hat.png"))
        this.load.image('Common_myHAK',require("../assets/images/maj/my/hak.png"))
    }
    create(){
        this.preloadBar.cropEnabled = false;
        this.scene.start('GameScene');
    }
    update(){
        //游戏逻辑实现
    }
    render(){
        //游戏自定义渲染
    }
};