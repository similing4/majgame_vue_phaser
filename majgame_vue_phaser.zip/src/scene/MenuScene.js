import Phaser from 'phaser';
import Sakura from "../util/sakura.js"
import Config from "../config/gameconf.js"

export default class MenuScene extends Phaser.Scene {
    init(){
        this.usernameText = null; //用户名文本
        this.userIdText = null; //用户ID文本
        this.userMoneyText = null; //用户钱数文本
        
        this.monenyBar = null; //用户钱数区域按钮
        this.charactorChangeCardBar = null; //换角色卡区域按钮
        this.createRoomBtn = null; //创建房间按钮
        this.joinRoomBtn = null; //加入房间按钮
    }
    preload(){
        //游戏资源预加载
    }
    create(){
        this.add.sprite(0, 0, 'MenuScene_background').setOrigin(0, 0);
        this.add.sprite(0, 0, 'MenuScene_topBar').setOrigin(0, 0);
        this.add.sprite(0, 944, 'MenuScene_bottomBar').setOrigin(0, 0);
        this.charactorChangeCardBar = this.add.sprite(1379, 47, 'MenuScene_charactorChangeCardBar').setOrigin(0, 0);
        this.add.sprite(358, 960, 'MenuScene_activityBtn').setOrigin(0, 0);
        this.add.sprite(716, 960, 'MenuScene_settingBtn').setOrigin(0, 0);
        this.add.sprite(1074, 960, 'MenuScene_shopBtn').setOrigin(0, 0);
        this.add.sprite(1432, 960, 'MenuScene_zhanjiBtn').setOrigin(0, 0);
        this.add.sprite(1770, 16, 'MenuScene_Message').setOrigin(0, 0);
        this.monenyBar = this.add.sprite(988, 47, 'MenuScene_moneyBar').setOrigin(0, 0);
        this.add.sprite(43, 17, 'MenuScene_userIcon').setOrigin(0, 0);
        this.add.sprite(36, 10, 'MenuScene_userBar').setOrigin(0, 0);
        this.createRoomBtn = this.add.sprite(656, 300, 'MenuScene_roomCreateBtn').setOrigin(0, 0);
        this.joinRoomBtn = this.add.sprite(656, 600, 'MenuScene_roomInBtn').setOrigin(0, 0);
        this.usernameText = this.add.text(200, 39, '滑稽保命', {
            fontFamily: 'cangershuyuanti',
            fill: "#FFFFFF",
            fontSize: 30,
            stroke: '#e23',
            strokeThickness: 2
        }).setOrigin(0, 0);
        this.userIdText = this.add.text(240, 78, '1', {
            fontFamily: 'notoSerif',
            fill: "#3fff22",
            fontSize: 35,
            stroke: '#333',
            strokeThickness: 5
        }).setOrigin(0, 0);
        this.userMoneyText = this.add.text(1065, 57, '0', {
            fontFamily: 'notoSerif',
            fill: "#FFFFFF",
            fontSize: 36,
            stroke: '#333',
            strokeThickness: 5
        }).setOrigin(0, 0);
        this.userChangeCardNumText = this.add.text(1455, 57, '0', {
            fontFamily: 'notoSerif',
            fill: "#FFFFFF",
            fontSize: 36,
            stroke: '#333',
            strokeThickness: 5
        }).setOrigin(0, 0);
        this.sakuraFall = new Sakura(this,Config.initGameConf.scale.width,Config.initGameConf.scale.height);
        this.sakuraFall.createParticles();
        console.log(Config);

        this.monenyBar.setInteractive();
        this.charactorChangeCardBar.setInteractive();
        this.createRoomBtn.setInteractive();
        this.joinRoomBtn.setInteractive();
        this.monenyBar.on('pointerdown', (e)=>{this.onMoneyBarClick(e)});
        this.charactorChangeCardBar.on('pointerdown', (e)=>{this.onCharactorChangeCardBarClick(e)});
        this.createRoomBtn.on('pointerdown', (e)=>{this.onCreateRoomBtnClick(e)});
        this.joinRoomBtn.on('pointerdown', (e)=>{this.onJoinRoomBtnClick(e)});
    }
    update(){
    }
    render(){
        //游戏自定义渲染
    }
    onMoneyBarClick(e){
        console.log(e);
    }
    onCharactorChangeCardBarClick(e){
        console.log(e);
    }
    onCreateRoomBtnClick(e){
        this.scene.start('GamePreloadScene');
    }
    onJoinRoomBtnClick(e){
        console.log(e);
    }
};