import Phaser from "phaser";

export default {
    initGameConf: {
        scale: {
            parent: 'game-area',
            mode: Phaser.Scale.FIT,
            width: 1920,
            height: 1080
        },
        autoCenter: Phaser.Scale.CENTER_HORIZONTALLY,
        type: Phaser.AUTO,
        title: '测试',
        localStorageName: '测试'
    },
    gameOption: {
        "scenes": {
            "BootScene": require("../scene/BootScene.js"),
            "PreloadScene": require("../scene/PreloadScene.js"),
            "MenuScene": require("../scene/MenuScene.js"),
            "GamePreloadScene": require("../scene/GamePreloadScene.js"),
            "GameScene": require("../scene/GameScene.js")
        }
    }
}