import Phaser from 'phaser';
import Config from './config/gameconf.js';
import "./index.less";

class Game extends Phaser.Game {
    constructor() {
        super(Config.initGameConf);
		this.isInit = false;
        this.changeTo('BootScene');
    }
    /**
     * 切换场景方法，传入场景值即可切换
     * @param targetScene 需要转换的目标场景
     */
    changeTo(targetScene) {
        if (!this.isInit) {
            this.initScene();
        }
        this.scene.start(targetScene);
    };

    initScene() {
    	for(var i in Config.gameOption.scenes){
        	this.scene.add(i, Config.gameOption.scenes[i].default);
        }
        console.log();
        this.isInit = true;
    };
}
window.game = new Game();